var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _ControlsHandler_mouseX, _ControlsHandler_mouseY, _ControlsHandler_mouseDown, _ControlsHandler_mouseClicked;
export class ControlsHandler {
    constructor(canvas) {
        _ControlsHandler_mouseX.set(this, 0);
        _ControlsHandler_mouseY.set(this, 0);
        _ControlsHandler_mouseDown.set(this, false);
        _ControlsHandler_mouseClicked.set(this, false);
        let self = this;
        canvas.addEventListener("mousemove", function (evt) {
            let rect = canvas.getBoundingClientRect();
            __classPrivateFieldSet(self, _ControlsHandler_mouseX, evt.clientX - rect.left, "f");
            __classPrivateFieldSet(self, _ControlsHandler_mouseY, evt.clientY - rect.top, "f");
        });
        canvas.addEventListener("mousedown", function (_) {
            __classPrivateFieldSet(self, _ControlsHandler_mouseDown, true, "f");
            __classPrivateFieldSet(self, _ControlsHandler_mouseClicked, true, "f");
        });
        canvas.addEventListener("mouseup", function (_) {
            __classPrivateFieldSet(self, _ControlsHandler_mouseDown, false, "f");
            __classPrivateFieldSet(self, _ControlsHandler_mouseClicked, false, "f");
        });
    }
    tick() {
        __classPrivateFieldSet(this, _ControlsHandler_mouseClicked, false, "f");
    }
    mousePos() {
        return { x: __classPrivateFieldGet(this, _ControlsHandler_mouseX, "f"), y: __classPrivateFieldGet(this, _ControlsHandler_mouseY, "f") };
    }
    mouseDown() {
        return __classPrivateFieldGet(this, _ControlsHandler_mouseDown, "f");
    }
    mouseClicked() {
        return __classPrivateFieldGet(this, _ControlsHandler_mouseClicked, "f");
    }
}
_ControlsHandler_mouseX = new WeakMap(), _ControlsHandler_mouseY = new WeakMap(), _ControlsHandler_mouseDown = new WeakMap(), _ControlsHandler_mouseClicked = new WeakMap();
