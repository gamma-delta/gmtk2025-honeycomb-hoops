// Yoink
// https://github.com/gamma-delta/gmtk-2022/blob/main/src/widget.ts
import { CONTROLS, CTX } from "./main.js";
export class Widget {
    constructor(state, x, y, w, h) {
        this.isHovered = false;
        this.state = state;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    update() {
        let mousePos = CONTROLS.mousePos();
        const hovering = mousePos.x >= this.x
            && mousePos.x <= this.x + this.w
            && mousePos.y >= this.y
            && mousePos.y <= this.y + this.h;
        if (hovering != this.isHovered) {
            this.isHovered = hovering;
            this.onHoverChange();
        }
        if (hovering && CONTROLS.mouseClicked()) {
            this.onClick();
        }
    }
    onHoverChange() { }
    center() {
        return {
            x: this.x + this.w / 2,
            y: this.y + this.h / 2,
        };
    }
    outline(fill, stroke, width = 4) {
        CTX.fillStyle = fill;
        CTX.fillRect(this.x, this.y, this.w, this.h);
        CTX.strokeStyle = stroke;
        CTX.lineWidth = width;
        CTX.strokeRect(this.x, this.y, this.w, this.h);
    }
    centerText(text) {
        let metrics = CTX.measureText(text);
        CTX.fillText(text, this.x + this.w / 2, this.y + this.h / 2
            + (metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent) / 2);
    }
}
export class ClickButton extends Widget {
    constructor(state, x, y, w, h, text, onClickLambda) {
        super(state, x, y, w, h);
        this.text = text;
        this.onClickLambda = onClickLambda;
    }
    onClick() {
        this.onClickLambda();
    }
    draw() {
        this.outline("white", "black");
        CTX.textAlign = "center";
        CTX.font = `40px "Courier New", sans-serif`;
        CTX.fillStyle = "black";
        this.centerText(this.text);
    }
}
