import { CANVAS, CTX } from "../main.js";
import { Puzzle } from "../puzzle.js";
import { puzzlePacks } from "../puzzleList.js";
import { SOUNDS } from "../sounds.js";
import { Widget } from "../widget.js";
import { StatePlayPuzzle } from "./playPuzzle.js";
const PUZZLES_ACROSS = 8;
const PADDING = 20;
export class StatePickPuzzle {
    constructor() {
        this.pickedIndex = null;
        this.widgets = puzzlePacks.map((pp, idx) => {
            return new LevelButton(this, pp.source, idx);
        });
    }
    update() {
        for (let w of this.widgets) {
            w.update();
        }
        if (this.pickedIndex !== null) {
            let idx = this.pickedIndex;
            this.pickedIndex = null;
            return {
                type: "push",
                state: new StatePlayPuzzle(idx),
            };
        }
        return null;
    }
    draw() {
        CTX.fillStyle = "white";
        CTX.fillRect(0, 0, CANVAS.width, CANVAS.height);
        for (let w of this.widgets) {
            w.draw();
        }
    }
    drawTransparent() {
        return false;
    }
}
class LevelButton extends Widget {
    constructor(state, puzzleSrc, idx) {
        let sqX = idx % PUZZLES_ACROSS;
        let sqY = Math.floor(idx / PUZZLES_ACROSS);
        let strideX = (CANVAS.width - PADDING) / PUZZLES_ACROSS;
        let sz = strideX - PADDING;
        let pxX = PADDING + sqX * strideX;
        let pxY = PADDING + sqY * strideX;
        super(state, pxX, pxY, sz, sz);
        this.puzzle = new Puzzle(puzzleSrc, true, {
            x: pxX + sz / 2,
            y: pxY + sz / 2
        });
        this.idx = idx;
    }
    onClick() {
        this.state.pickedIndex = this.idx;
        SOUNDS.button_down.pickAndPlay();
    }
    draw() {
        this.outline("white", this.isHovered ? "#222" : "#999", 2);
        this.puzzle.draw();
    }
}
