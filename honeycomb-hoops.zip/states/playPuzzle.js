import { CANVAS, CTX } from "../main.js";
import { Puzzle } from "../puzzle.js";
import { puzzlePacks } from "../puzzleList.js";
import { SOUNDS } from "../sounds.js";
import * as Util from "../util.js";
import { Widget } from "../widget.js";
import { StateYouWin } from "./win.js";
const BUTTON_WIDTH = 250;
const BUTTON_HEIGHT = 80;
export class StatePlayPuzzle {
    constructor(puzzleIndex) {
        this.goToNextPuzzle = false;
        this.exitBack = false;
        this.puzzleIndex = puzzleIndex;
        let puzzle = puzzlePacks[puzzleIndex];
        this.puzzle = new Puzzle(puzzle.source);
        this.sidebar = puzzle.sidebar;
        this.widgets = [];
        let centerX = CANVAS.width / 2;
        let centerY = CANVAS.height / 2;
        let columnLhs = CANVAS.width - BUTTON_WIDTH * 1.5;
        let buttonStartY = centerY - BUTTON_HEIGHT / 2;
        this.widgets.push(new EraseModeButton(this, columnLhs, buttonStartY));
        this.widgets.push(new BackToLevelSelectButton(this, columnLhs, buttonStartY + 120));
        this.widgets.push(new NextLevelButton(this, columnLhs, buttonStartY + 240));
    }
    update() {
        if (this.goToNextPuzzle) {
            if (this.puzzleIndex == puzzlePacks.length - 1) {
                return {
                    type: "swap",
                    state: new StateYouWin(),
                };
            }
            else {
                return {
                    type: "swap",
                    state: new StatePlayPuzzle(this.puzzleIndex + 1),
                };
            }
        }
        else if (this.exitBack) {
            return { type: "pop" };
        }
        this.puzzle.update();
        for (let w of this.widgets) {
            w.update();
        }
        return null;
    }
    draw() {
        CTX.fillStyle = "white";
        CTX.fillRect(0, 0, CANVAS.width, CANVAS.height);
        this.puzzle.draw();
        CTX.fillStyle = "#222";
        CTX.textAlign = "start";
        CTX.font = `24px "Courier New", sans-serif`;
        Util.drawTextWithNewlines(this.sidebar, 20, 40);
        for (let w of this.widgets) {
            w.draw();
        }
    }
    drawTransparent() {
        return false;
    }
}
class EraseModeButton extends Widget {
    constructor(state, x, y) {
        super(state, x, y, BUTTON_WIDTH, BUTTON_HEIGHT);
    }
    onClick() {
        if (!this.state.puzzle.won) {
            let em = this.state.puzzle.eraseMode;
            this.state.puzzle.eraseMode = !em;
            if (em)
                SOUNDS.button_down.pickAndPlay();
            else
                SOUNDS.button_up.pickAndPlay();
        }
    }
    draw() {
        let darkColor;
        if (!this.state.puzzle.won
            && (this.state.puzzle.eraseMode || this.isHovered)) {
            darkColor = "#444";
        }
        else {
            darkColor = "#999";
        }
        this.outline(this.state.puzzle.eraseMode ? "#EBB" : "white", darkColor);
        CTX.textAlign = "center";
        CTX.font = `24px "Courier New", sans-serif`;
        CTX.fillStyle = darkColor;
        this.centerText(this.state.puzzle.eraseMode ? "Eraser: On" : "Eraser: Off");
    }
}
class BackToLevelSelectButton extends Widget {
    constructor(state, x, y) {
        super(state, x, y, BUTTON_WIDTH, BUTTON_HEIGHT);
    }
    onClick() {
        SOUNDS.button_down.pickAndPlay();
        this.state.exitBack = true;
    }
    draw() {
        let darkColor;
        if (this.isHovered) {
            darkColor = "#444";
        }
        else {
            darkColor = "#999";
        }
        this.outline("white", darkColor);
        CTX.textAlign = "center";
        CTX.font = `24px "Courier New", sans-serif`;
        CTX.fillStyle = darkColor;
        this.centerText("Level Select");
    }
}
class NextLevelButton extends Widget {
    constructor(state, x, y) {
        super(state, x, y, BUTTON_WIDTH, BUTTON_HEIGHT);
    }
    onClick() {
        if (this.state.puzzle.won) {
            this.state.goToNextPuzzle = true;
            SOUNDS.button_down.pickAndPlay();
        }
    }
    draw() {
        if (this.state.puzzle.won) {
            this.outline("#BFB", "#222");
            CTX.textAlign = "center";
            CTX.font = `24px "Courier New", sans-serif`;
            CTX.fillStyle = "#222";
            this.centerText("Next Level");
        }
    }
}
